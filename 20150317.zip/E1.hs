vendas :: Int -> Int
vendas v
 | v < 5 = 2
 | otherwise = 3

igual :: Int -> Int -> Int
igual n m 
 | n == m = 1
 | otherwise = 0

totalIgual :: Int -> Int -> Int
totalIgual s n 
 | n == 0 = igual (vendas(0)) (s)
 | otherwise = (totalIgual (s) (n-1)) + (igual (s) (vendas n))