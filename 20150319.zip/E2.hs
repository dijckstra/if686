{-| sumList with pattern matching
sumList [] = []
sumList (a:as) = a + sumList as
-}

double :: [Int] -> [Int]
double list
 | list == [] = []
 | otherwise = (head list * 2):(double (tail list))
 
{-| with pattern matching
double [] = []
double (a:as) = (a*2):(double as)
-}

member :: [Int] -> Int -> Bool
member list n
 | list == [] = False
 | head list == n = True
 | otherwise = member (tail list) n
 
type Str = [Char]
digits :: Str -> Str
digits str
 | str == [] = []	
 | (head str >= '0') && (head str <= '9') = (head str):digits(tail (str))
 | otherwise = digits (tail (str))

sumPairs :: [Int] -> [Int] -> [Int] 
sumPairs a b
 | a == [] || b == [] = []
 | otherwise = ((head a) + (head b)):(sumPairs (tail (a)) (tail (b)))
 
{-| with pattern matching
sumPairs as [] = []
sumPairs [] bs = []
sumPairs (a:as) (b:bs) = (a + b):(sumPairs as bs)
-}