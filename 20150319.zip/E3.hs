smaller :: (Ord a) => [a] -> a -> [a]
smaller [] s = []
smaller (s:ss) x
 | s < x = s:(smaller ss x)
 | otherwise = smaller ss x

greater :: (Ord a) => [a] -> a -> [a]
greater [] g = []
greater (g:gs) x
 | g >= x = g:(greater gs x)
 | otherwise = greater gs x

quicksort :: (Ord a) => [a] -> [a]
quicksort [] = []
quicksort (x:xs) = (quicksort left) ++ [x] ++ (quicksort right)
 where
 	left = smaller xs x
 	right = greater xs x